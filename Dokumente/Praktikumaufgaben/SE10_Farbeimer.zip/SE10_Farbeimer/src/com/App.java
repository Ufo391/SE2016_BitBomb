package com;

import mvc.Controller;

public class App {
	
	static Controller controller;

	public static void main(String[] args) {
				
		controller = new Controller();
		controller.showView();
	}

}
