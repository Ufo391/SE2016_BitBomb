package mvc;

import java.util.Observable;

public class Model extends Observable {
	
	//Attribute
	private float heigth; // in Meter
	private float width; // in Meter
	private float consumRate; //Verbrauch in Milliliter / Quadratmeter
	private float amount; // Farbe pro Eimer in Liter
	private int bukkit; // ben�tigte Eimer Farbe
	private float reqLiter; // ben�tigte Liter Farbe
	
	
	//Konsturktoren
	public Model(){
		this.heigth = 0;
		this.width = 0;
		this.consumRate = 0;
		this.amount = 0;
		this.bukkit = 0;
		this.reqLiter = 0;
	}
	
	public Model(float height, float width, float consumRate, float amount){
		this.heigth = height;
		this.width = width;
		this.consumRate = consumRate;
		this.amount = amount;
		this.bukkit = 0;
		this.reqLiter = 0;
	}
	
	public Model(float height, float width, float consumRate, float amount, int bukkit){
		this.heigth = height;
		this.width = width;
		this.consumRate = consumRate;
		this.amount = amount;
		this.bukkit = bukkit;
		this.reqLiter = 0;
	}
	
	
	//Funktionen
	public void calc(){
		float qm = heigth * width;
		reqLiter = (consumRate * qm) / 1000;
		bukkit = (int) ((reqLiter / amount) + 0.5);	
		if(reqLiter > 0 && bukkit == 0){bukkit = 1;}
		
		this.setChanged();
		this.notifyObservers();
	}

	
	//GET & SET
	public float getHeigth() {
		return heigth;
	}

	public void setHeigth(float heigth) throws Exception {
		if(heigth > 0 && heigth <= 100){
			this.heigth = heigth;
		}else{
			throw new Exception();
		}
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) throws Exception {		
		if(width > 0 && width <= 100){
			this.width = width;			
		}else{
			throw new Exception();
		}
	}

	public float getConsumRate() {
		return consumRate;
	}

	public void setConsumRate(float consumRate) throws Exception {
		if(consumRate > 0){
			this.consumRate = consumRate;			
		}else{
			throw new Exception();
		}
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) throws Exception {
		if(amount > 0){
			this.amount = amount;			
		}else{
			throw new Exception();
		}
	}

	public int getBukkit() {
		return bukkit;
	}
	
	public float getReqLiter() {
		return reqLiter;
	}
	
}
