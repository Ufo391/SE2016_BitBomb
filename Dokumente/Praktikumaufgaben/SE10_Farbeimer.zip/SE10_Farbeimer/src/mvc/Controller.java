package mvc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class Controller {
	
	//Attribute
	private View view;
	private Model model;
	
	//Konstruktor
	public Controller(){
		view = new View();
		model = new Model();
		
		model.addObserver(view);
		addListener();
	}
	
	//Funktionen
	public void showView(){
		this.view.show();
	}
	
	private void addListener(){
		view.setButtonStartListener(new StartButtonListener());
	}
	
	//innere Klasse
    class StartButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent e) {
        	if(view.validateInputs() == true){
        		try {
					model.setHeigth(Float.parseFloat(view.getText_height().getText()));
	    			model.setWidth(Float.parseFloat(view.getText_width().getText()));
	    			model.setAmount(Float.parseFloat(view.getText_amountBukkit().getText()));
	    			model.setConsumRate(Float.parseFloat(view.getText_req().getText()));
	    			
	    			model.calc();	
				} catch (Exception e1) {
					e1.printStackTrace();
				}
        	}    			    			
        }
    }

	
    //GET
    public View getView() {
		return view;
	}

	public Model getModel() {
		return model;
	}

    
}
