package mvc;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class View implements Observer{
	
	//Attribtute
	private JFrame frame_input, frame_liter, frame_bukkit;
	private JTextField text_height, text_width, text_req, text_amountBukkit;
	private JLabel label_height, label_width, label_req,label_amountBukkit, label_bukkitNeed, label_literNeed;
	private FlowLayout layout;
	private JButton button_start;
	
	//Konstruktoren
	public View(){		
		init();
	}
	
	//Funktionen
	private void init(){
		
	layout = new FlowLayout();
     build_FrameBukkit();
     build_FrameInput();
     build_FrameLiter();
     
	}
	
	private void build_FrameInput(){
        //Frame
        frame_input = new JFrame("");        
        frame_input.setSize(150, 270);
        frame_input.setLocationRelativeTo(null);
        frame_input.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Layout        
        frame_input.setLayout(layout);
        //Textbox
        text_height = new JTextField(10);
        text_width = new JTextField(10);
        text_req = new JTextField(10);
        text_amountBukkit = new JTextField(10);
        //Textbox Label
        label_height = new JLabel("h�he:");
        label_width = new JLabel("breite:");
        label_req = new JLabel("Verbrauch: ml/QM");
        label_amountBukkit = new JLabel("Literfarbe / Eimer");
        //Button
        button_start = new JButton("Best�tigen");        
        
        
        frame_input.add(label_height);
        frame_input.add(text_height);
        
        frame_input.add(label_width);
        frame_input.add(text_width);
        
        frame_input.add(label_req);
        frame_input.add(text_req);
        
        frame_input.add(label_amountBukkit);
        frame_input.add(text_amountBukkit);
        
        frame_input.add(button_start);  
	}
	
	private void build_FrameLiter(){
        //Frame
        frame_liter = new JFrame("Liter");        
        frame_liter.setSize(200, 100);
        frame_liter.setLocationRelativeTo(frame_input);
        frame_liter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Layout        
        frame_input.setLayout(layout);
        //Label
        label_literNeed = new JLabel("Liter: -");
        
        frame_liter.add(label_literNeed);
	}
	
	private void build_FrameBukkit(){
        //Frame
		frame_bukkit = new JFrame("Eimer");        
		frame_bukkit.setSize(200, 100);
		frame_bukkit.setLocationRelativeTo(frame_liter);
		frame_bukkit.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Layout        
		frame_bukkit.setLayout(layout);
		//Label
		label_bukkitNeed = new JLabel("Eimer: -");
		
		frame_bukkit.add(label_bukkitNeed);
	}	
	
	
	public void clearInput(){
		text_amountBukkit.setText("");
		text_height.setText("");
		text_req.setText("");
		text_width.setText("");
	}
	
	public void show(){
        frame_input.setVisible(true);
        frame_liter.setVisible(true);
        frame_bukkit.setVisible(true);
        frame_liter.setLocation(frame_input.getX() - frame_liter.getSize().width, frame_input.getY());
        frame_bukkit.setLocation(frame_input.getX() + frame_input.getSize().width, frame_input.getY());
	}
	
	public boolean validateInputs(){		
	 try {  
	     Float.parseFloat(this.text_amountBukkit.getText());
	     Float.parseFloat(this.text_height.getText());  
	     Float.parseFloat(this.text_req.getText());  
	     Float.parseFloat(this.text_width.getText());  
	     return true;  
	  } catch (NumberFormatException e) { 
		JOptionPane.showMessageDialog(null, "Ung�ltge Eingabe", "FEHLER", JOptionPane.OK_CANCEL_OPTION);
		clearInput();
	    return false;  
	  }  
	}
	
	//Events
	@Override
	public void update(Observable arg0, Object arg1) {
		if(arg0 instanceof Model){
			Model tmp = (Model) arg0;
			label_bukkitNeed.setText("Eimer: " + tmp.getBukkit());
			label_literNeed.setText("Liter: " + tmp.getReqLiter());
			clearInput();
		}				
	}

    public void setButtonStartListener(ActionListener l){
        this.button_start.addActionListener(l);
    }

	
    //GET
    public JFrame getFrame_input() {
		return frame_input;
	}

	public JFrame getFrame_liter() {
		return frame_liter;
	}

	public JFrame getFrame_bukkit() {
		return frame_bukkit;
	}

	public JTextField getText_height() {
		return text_height;
	}

	public JTextField getText_width() {
		return text_width;
	}

	public JTextField getText_req() {
		return text_req;
	}

	public JTextField getText_amountBukkit() {
		return text_amountBukkit;
	}	
  
}
