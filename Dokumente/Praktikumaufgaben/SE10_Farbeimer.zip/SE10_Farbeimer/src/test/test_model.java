package test;

import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;
import mvc.Controller;
import mvc.Model;
import mvc.View;

@SuppressWarnings("deprecation")
public class test_model {
	
	Model model;
	View view;
	Controller controller;

	@Before
	public void setUp() throws Exception {
		controller = new Controller();
		view = controller.getView();
		model = controller.getModel();
	}

	@Test(expected=Exception.class)
	public void testSizeXnegativ() throws Exception {
		model.setWidth(-5);
	}
	
	@Test(expected=Exception.class)
	public void testSizeYnegativ() throws Exception {
		model.setHeigth(-5);
	}
	
	@Test(expected=Exception.class)
	public void testSizeX() throws Exception {
		model.setWidth(101);
	}
	
	@Test(expected=Exception.class)
	public void testSizeY() throws Exception {
		model.setHeigth(101);
	}

	@Test(expected=Exception.class)
	public void testAmountNegative() throws Exception{
		model.setAmount(-5);
	}
	
	@Test(expected=Exception.class)
	public void testConsumRateNegative() throws Exception{
		model.setConsumRate(-5);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void TestCalcBukkit() throws Exception{
		model.setHeigth(4);
		model.setWidth(5);
		model.setConsumRate(200);
		model.setAmount(2);
		model.calc();
		Assert.assertEquals(2, model.getBukkit());
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void TestCalcLiter() throws Exception{
		model.setHeigth(4);
		model.setWidth(5);
		model.setConsumRate(200);
		model.setAmount(2);
		model.calc();
		Assert.assertEquals((float)4.0, model.getReqLiter());
	}
}
